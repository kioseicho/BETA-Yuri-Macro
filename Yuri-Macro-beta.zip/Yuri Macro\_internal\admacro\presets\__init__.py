"""Starter templates cropped from real game screenshots (see tools/build_presets.py).

They are installed into the user's templates folder at startup for every name
the user hasn't calibrated themselves; a template captured in the Calibration
tab always wins. Re-capturing at your own window size is still recommended.
"""
from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path

from ..core.paths import resource_path

log = logging.getLogger("admacro.presets")


def preset_dir() -> Path:
    d = Path(__file__).resolve().parent
    return d if (d / "presets.json").exists() else resource_path("admacro/presets")


def load_presets() -> dict[str, dict]:
    path = preset_dir() / "presets.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def install_presets(settings, templates_folder: Path, overwrite_presets: bool = False) -> list[str]:
    """Copy starter templates in. Never replaces a template the user captured.

    A template that is still a starter one is refreshed automatically when the shipped
    version changed (new image or metadata, e.g. re-captured at the docked 1152x648);
    ``overwrite_presets`` refreshes all of them regardless."""
    presets = load_presets()
    if not presets:
        return []
    templates = settings.get("templates", {}) or {}
    installed = []
    src_dir = preset_dir() / "templates"
    for name, meta in presets.items():
        cur = templates.get(name)
        src = src_dir / meta["file"]
        if not src.exists():
            continue
        fname = "preset_" + meta["file"]
        if cur and not (cur.get("preset") and overwrite_presets):
            if not cur.get("preset"):
                continue                      # the user captured this one: never touch it
            installed_file = templates_folder / cur["file"]
            same = (installed_file.exists() and installed_file.read_bytes() == src.read_bytes()
                    and {**meta, "file": fname, "preset": True} == cur)
            if same:
                continue
        shutil.copyfile(src, templates_folder / fname)
        templates[name] = {**meta, "file": fname, "preset": True}
        installed.append(name)
    if installed:
        settings.set("templates", templates, save=True)
        log.info("installed %d starter template(s): %s", len(installed), ", ".join(installed))
    return installed
